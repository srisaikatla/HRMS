import React from "react";

function Leaves_HolidaysPolicy() {
  return <div></div>;
}

export default Leaves_HolidaysPolicy;
