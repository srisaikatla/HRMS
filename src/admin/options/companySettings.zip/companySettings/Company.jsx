import React from "react";

function Company() {
  return <div></div>;
}

export default Company;
