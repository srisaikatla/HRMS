import React from "react";

function Shifts() {
  return <div></div>;
}

export default Shifts;
