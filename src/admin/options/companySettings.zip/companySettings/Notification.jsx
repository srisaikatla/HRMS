import React from "react";

function Notification() {
  return <div></div>;
}

export default Notification;
