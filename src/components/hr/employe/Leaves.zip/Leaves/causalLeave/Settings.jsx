import React from "react";

function Settings() {
  return <div>settings</div>;
}

export default Settings;
